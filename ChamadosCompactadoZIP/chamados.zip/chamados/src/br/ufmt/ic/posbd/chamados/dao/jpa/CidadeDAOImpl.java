package br.ufmt.ic.posbd.chamados.dao.jpa;

import br.ufmt.ic.posbd.chamados.dao.CidadeDAO;
import br.ufmt.ic.posbd.chamadosMySQL.entidade.Cidade;

public class CidadeDAOImpl extends DAOImpl<Cidade> implements CidadeDAO{
    
}
