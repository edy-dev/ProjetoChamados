/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.ufmt.ic.posbd.chamados.dao;

import br.ufmt.ic.posbd.chamadosMySQL.entidade.Hardware;

/**
 *
 * @author edy
 */
public interface HardwareDAO extends DAO<Hardware>{
    
}
