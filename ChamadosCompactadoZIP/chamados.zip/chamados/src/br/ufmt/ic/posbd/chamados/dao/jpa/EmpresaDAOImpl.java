package br.ufmt.ic.posbd.chamados.dao.jpa;

import br.ufmt.ic.posbd.chamados.dao.EmpresaDAO;
import br.ufmt.ic.posbd.chamadosMySQL.entidade.Empresa;

public class EmpresaDAOImpl extends DAOImpl<Empresa> implements EmpresaDAO{
    
}
