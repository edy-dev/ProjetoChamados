package br.ufmt.ic.posbd.chamados.dao.jpa;

import br.ufmt.ic.posbd.chamados.dao.SolicitanteDAO;
import br.ufmt.ic.posbd.chamadosPostgres.entidade.Solicitante;





public class SolicitanteDAOImpl extends DAOImpl<Solicitante> implements SolicitanteDAO{
    
}
