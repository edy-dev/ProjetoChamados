package br.ufmt.ic.posbd.chamados.dao.jpa;

import br.ufmt.ic.posbd.chamados.dao.RegistrosDAO;
import br.ufmt.ic.posbd.chamadosPostgres.entidade.Registros;

public class RegistrosDAOImpl extends DAOImpl<Registros> implements RegistrosDAO{
    
}
