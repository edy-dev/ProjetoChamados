package br.ufmt.ic.posbd.chamados.dao.jpa;

import br.ufmt.ic.posbd.chamados.dao.HardwareDAO;
import br.ufmt.ic.posbd.chamadosMySQL.entidade.Hardware;

public class HardwareDAOImpl extends DAOImpl<Hardware> implements HardwareDAO{
    
}
